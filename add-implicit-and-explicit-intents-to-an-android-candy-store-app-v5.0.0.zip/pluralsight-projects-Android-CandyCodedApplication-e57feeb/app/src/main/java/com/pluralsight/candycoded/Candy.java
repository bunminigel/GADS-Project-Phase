package com.pluralsight.candycoded;

public class Candy {
    public int id;
    public String name;
    public String image;
    public String price;
    public String description;
}
